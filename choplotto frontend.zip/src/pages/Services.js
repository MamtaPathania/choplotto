import React from 'react'
import Layout from '../components/Layout'

function Services() {
  return (
    <Layout>
         <div className=''>
      services
    </div>
    </Layout>
   
  )
}

export default Services
