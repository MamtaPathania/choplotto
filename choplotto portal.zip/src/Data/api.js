
const baseURL='https://jsonplaceholder.typicode.com/users'

export { baseURL };


