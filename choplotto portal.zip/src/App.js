
import { BrowserRouter, Routes, Route } from 'react-router-dom'

import Dashboard from './pages/Dashboard'
import Subscriber from './pages/Subscriber'
import Subscription from './pages/Subscription'
import Prediction from './pages/Prediction'
import Services from './pages/Services'
import { useContext } from 'react'
import { ThemeContext } from './components/ThemeContext'
function App() {
    const { theme } = useContext(ThemeContext);
    
    return (
        <div className={`${theme === 'dark' ? 'bg-black shadow-black text-white' : 'bg-white'}`}>
            <BrowserRouter>
        
                  
        <Routes>
            
            <Route path='/' element={<Dashboard />} />
            <Route path='/subscribers' element={<Subscriber/>} />
            <Route path='/subscription' element={<Subscription/>} />
            <Route path='/predictions' element={<Prediction/>} />
            <Route path='/services' element={<Services/>}/>
        </Routes>

</BrowserRouter>
        </div>
        

        
        
    )
}

export default App
