import React from 'react'
import Layout from '../components/Layout'

function Subscription() {
  return (
    <Layout>
        <div className='text-center'>
      subscription
    </div>
    </Layout>
    
  )
}

export default Subscription
