import React, { useState } from "react";
import Layout from "../components/Layout";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const Dashboard = () => {
  const [selectedDate, setSelectedDate] = useState(null);

  // Handle date change
  const handleDateChange = (date) => {
    setSelectedDate(date);
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedDate) {
      alert(`Selected Date: ${selectedDate.toLocaleDateString()}`);
    } else {
      alert("Please select a date.");
    }
  };

  return (
    <Layout>
      <div className="flex justify-center items-center mt-10">
        <form
          onSubmit={handleSubmit}
          className="flex flex-col items-center space-y-4 bg-gray-100 p-6 rounded-lg shadow-lg lg:w-[400px] "
        >
          <div className="flex items-center space-x-4 w-full">
            <label htmlFor="date-picker" className="text-lg font-medium">
              Select Date:
            </label>
            <DatePicker
              selected={selectedDate}
              onChange={handleDateChange}
              dateFormat="yyyy-MM-dd"
              className="border p-2 rounded w-full"
              id="date-picker"
              placeholderText="Select a date"
            />
          </div>
          <button
            type="submit"
            className="bg-blue-500 text-white p-2 rounded hover:bg-blue-400 w-[90px] mt-4"
          >
            Submit
          </button>
        </form>
      </div>
    </Layout>
  );
};

export default Dashboard;
