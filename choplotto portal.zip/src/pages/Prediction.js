import React from 'react'
import Layout from '../components/Layout'

function Prediction() {
  return (
    <Layout>
         <div>
      <form>
        <h1></h1>
      </form>
    </div>
    </Layout>
   
  )
}

export default Prediction
