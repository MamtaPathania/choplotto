

import React, { useState } from 'react';
import axios from 'axios';
import Layout from '../components/Layout';
import { TreeTable } from 'primereact/treetable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { IconField } from 'primereact/iconfield';
import { InputIcon } from 'primereact/inputicon';
import { SelectButton } from 'primereact/selectbutton';
import './styles.css'; // Import custom styles
import { baseURL } from '../Data/api';

function Subscriber() {
  const [users, setUsers] = useState([]);
  const [nodes, setNodes] = useState([]);
  const [globalFilter, setGlobalFilter] = useState('');
  const [filterMode, setFilterMode] = useState('lenient');

  const handleSubmit = async () => {
    try {
      const response = await axios.get(`${baseURL}`);
      setUsers(response.data);
      const transformedNodes = transformData(response.data);
      setNodes(transformedNodes);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const transformData = (data) => {
    return data.map(user => ({
      key: user.id,
      data: {
        name: user.name,
        email: user.email,
        phone: user.phone,
        company: user.company.name
      }
    }));
  };

  const getHeader = () => {
    return (
      <div className="flex justify-end">
        <IconField iconPosition="left">
          <InputIcon className="pi pi-search" />
          <InputText type="search" onInput={(e) => setGlobalFilter(e.target.value)} placeholder="Global Search" />
        </IconField>
      </div>
    );
  };

  const header = getHeader();

  return (
    <Layout>
      <div className="text-black text-center lg:ml-64">
        <button onClick={handleSubmit} className="text-xl bg-blue-500 rounded-lg hover:bg-blue-600 px-2 py-1 text-white">Submit</button>
        <div className="flex justify-center items-center mb-4">
          <SelectButton value={filterMode} onChange={(e) => setFilterMode(e.value)} />
        </div>
        <TreeTable className='w-[360px] sm:w-[660px] md:w-[740px] lg:w-full '
          value={nodes}
          globalFilter={globalFilter}
          paginator
          rows={5}
          rowsPerPageOptions={[5, 10, 25]}
          header={header}
          filterMode={filterMode}
          tableStyle={{ minWidth: '60rem', marginTop: '20px' }}
        >
          <Column field="name" header="Name" expander filter filterPlaceholder="Filter by name"></Column>
          <Column field="email" header="Email" filter filterPlaceholder="Filter by email"></Column>
          <Column field="phone" header="Phone" filter filterPlaceholder="Filter by phone"></Column>
          <Column field="company" header="Company" filter filterPlaceholder="Filter by company"></Column>
        </TreeTable>
      </div>
    </Layout>
  );
}

export default Subscriber;

