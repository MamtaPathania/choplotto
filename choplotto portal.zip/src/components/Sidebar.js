
import React, { useState, useContext } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BsChevronDown, BsChevronUp } from 'react-icons/bs';
import HamburgerButton from './HamburgerMenuButton/HamburgerButton';
import { GoHome } from "react-icons/go";
import { FiUsers } from "react-icons/fi";
import { IoCalendarOutline } from "react-icons/io5";
import { FaRegClock } from "react-icons/fa";
import { MdBatchPrediction, MdKeyboardArrowLeft } from "react-icons/md";
import ThemeToggle from './ThemeToggle';
import { ThemeContext } from './ThemeContext';

const Sidebar = () => {
    const [open, setOpen] = useState(true);
    const [mobileMenu, setMobileMenu] = useState(false);
    const [showSubcategories, setShowSubcategories] = useState(false);
    const [activeMenu, setActiveMenu] = useState(null); // For mobile menu
    const location = useLocation();
    const { theme } = useContext(ThemeContext);

    const Menus = [
        { title: 'Dashboard', path: '/', src: <GoHome size={25}/> },
        { title: 'Subscribers', path: '/subscribers', src: <FiUsers size={25} /> },
        { title: 'Subscription', path: '/subscription', src: <IoCalendarOutline size={25} /> },
        { title: 'Predictions', path: '#', src: <MdBatchPrediction size={25} />, hasSubcategories: true },
        { title: 'Services', path: '/services', src: <FaRegClock size={25} /> },
    ];

    const Subcategories = [
        { title: 'By Date', path: '/predictions/date' },
        { title: 'By Draw Date', path: '/predictions/draw_date' },
        { title: 'Manage Winning Numbers', path: '/predictions/winning_numbers' },
        { title: 'Search Winning', path: '/predictions/search' },
        { title: 'View Winning Tickets', path: '/predictions/tickets' },
    ];

    const handleMenuClick = (menuIndex) => {
        if (Menus[menuIndex].hasSubcategories) {
            setActiveMenu(activeMenu === menuIndex ? null : menuIndex);
        }
    };

    return (
        <>
            <div className={`fixed top-0 left-0 h-screen p-5 shadow duration-300 overflow-y-auto w-60 hidden lg:block ${theme === 'dark' ? 'bg-black shadow-gray-700' : 'bg-blue-400'} ${theme === 'dark' ? 'text-white' : 'text-white'}`}>
                <div className='flex justify-end'>
                    <ThemeToggle />
                </div>
                <div className="relative flex items-center justify-end pr-5">
                    {/* Removed the BsArrowLeftCircle component */}
                </div>
                <div className={`flex ${open && 'gap-x-4'} justify-center items-center mt-8`}>
                    {open && (
                        <span className='text-xl font-semibold whitespace-nowrap'>
                            Admin Menu
                        </span>
                    )}
                </div>
                <ul className='pt-3'>
                    {Menus.map((menu, index) => (
                        <React.Fragment key={index}>
                            <li
                                className={`group flex items-center justify-between gap-x-6 p-3 rounded-lg cursor-pointer hover:bg-white hover:text-black ${location.pathname === menu.path && 'bg-black/10'}`}
                                onClick={() => handleMenuClick(index)}
                            >
                                <Link to={menu.path} className="flex items-center w-full">
                                    <div className='flex items-center'>
                                        <span className='text-2xl group-hover:text-black'>{menu.src}</span>
                                        <span className={`${!open && 'hidden'} origin-left duration-300 group-hover:text-black`}>
                                            {menu.title}
                                        </span>
                                    </div>
                                </Link>
                                {menu.hasSubcategories && (
                                    <span className='text-xl group-hover:text-black'>
                                        {activeMenu === index ? <BsChevronUp /> : <BsChevronDown />}
                                    </span>
                                )}
                            </li>
                            {menu.hasSubcategories && activeMenu === index && (
                                <ul className='pl-1'>
                                    {Subcategories.map((subcategory, subIndex) => (
                                        <Link to={subcategory.path} key={subIndex}>
                                            <li className={`group flex items-center p-3 rounded-lg cursor-pointer hover:bg-white hover:text-black ${location.pathname === subcategory.path && 'bg-black/10'}`}>
                                                <span className='text-lg group-hover:text-black'><MdKeyboardArrowLeft /></span>
                                                <span className={`${!open && 'hidden'} origin-left duration-300 group-hover:text-black`}>
                                                    {subcategory.title}
                                                </span>
                                            </li>
                                        </Link>
                                    ))}
                                </ul>
                            
                            )}
                        </React.Fragment>
                    ))}
                </ul>
            </div>
            {/* Mobile Menu */}
            <div className="pt-3 lg:hidden">
                <HamburgerButton setMobileMenu={setMobileMenu} mobileMenu={mobileMenu} />
                
            </div>
            
            <div className="lg:hidden">
                <div className={`${mobileMenu ? 'flex' : 'hidden'} w-[300px] absolute z-50 flex-col items-center self-end py-8 mt-20 space-y-6 font-bold sm:w-auto left-6 right-6 ${theme === 'dark' ? 'bg-black' : 'bg-blue-400'} ${theme === 'dark' ? 'text-white' : 'text-white'} drop-shadow-md rounded-xl`}>
                    {Menus.map((menu, index) => (
                        <React.Fragment key={index}>
                            <div>
                                <Link to={menu.path} onClick={() => setMobileMenu(false)}>
                                    <span className={`${location.pathname === menu.path ? 'bg-gray-200' : ''} p-2 rounded-xl hover:bg-gray-200`}>
                                        {menu.title}
                                    </span>
                                </Link>
                                {menu.hasSubcategories && (
                                    <div className='flex flex-row'>
                                        <button
                                            className='text-xl'
                                            onClick={() => handleMenuClick(index)}
                                        >
                                            {activeMenu === index ? <BsChevronUp /> : <BsChevronDown />}
                                        </button>
                                        {activeMenu === index && (
                                            <ul className='pl-2'>
                                                {Subcategories.map((subcategory, subIndex) => (
                                                    <Link to={subcategory.path} key={subIndex} onClick={() => setMobileMenu(false)}>
                                                        <li className={`group flex items-center p-2 rounded-lg cursor-pointer hover:bg-gray-200 ${location.pathname === subcategory.path ? 'bg-gray-200' : ''}`}>
                                                            <span className='text-lg group-hover:text-black'><MdKeyboardArrowLeft /></span>
                                                            <span className='ml-2'>
                                                                
                                                                {subcategory.title}
                                                            </span>
                                                        </li>
                                                    </Link>
                                                ))}
                                            </ul>
                                        )}
                                    </div>
                                )}
                            </div>
                        </React.Fragment>
                    ))}
                </div>
                
            </div>
        </>
    );
};

export default Sidebar;
