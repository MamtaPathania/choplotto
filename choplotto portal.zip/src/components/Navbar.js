import React, { useContext } from 'react';
import { ThemeContext } from './ThemeContext';
import ThemeToggle from './ThemeToggle';

const Navbar = () => {
    const { theme } = useContext(ThemeContext);

    return (
        <nav className={`bg-slate shadow ${theme === 'dark' ? 'bg-black shadow-gray-700' : 'bg-blue-400 shadow-blue-200'} border-gray-200 mx-2 text-center px-2 rounded-lg`}>
            <div className='container flex justify-between ml-6 lg:ml-4 items-center mx-auto'>
           <div className='flex justify-end items-end ml-8 mt-6'>
           <ThemeToggle/>

           </div>

                <div className='flex items-center mx-auto justify-center'>
                    <h1 className='w-[160px] h-[70px] text-xl font-bold pt-6 text-white lg:ml-32 lg:mr-0 mr-24'>
                        Admin Panel
                    </h1>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;

